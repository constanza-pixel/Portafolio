(function () {
  'use strict';

  var raiz = document.documentElement;
  var boton = document.getElementById('btnTema');
  var icono = document.getElementById('iconoTema');
  var texto = document.getElementById('textoTema');

  // Refleja el tema actual en el botón (texto, icono y etiquetas de accesibilidad)
  function actualizarBoton(tema) {
    var oscuro = tema === 'dark';
    icono.textContent = oscuro ? '☀' : '☾';
    texto.textContent = oscuro ? 'Tema claro' : 'Tema oscuro';
    boton.setAttribute('aria-label', oscuro ? 'Cambiar a tema claro' : 'Cambiar a tema oscuro');
    boton.setAttribute('aria-pressed', String(oscuro));
  }

  function aplicarTema(tema) {
    raiz.setAttribute('data-bs-theme', tema);
    actualizarBoton(tema);
  }

  actualizarBoton(raiz.getAttribute('data-bs-theme'));

  boton.addEventListener('click', function () {
    var nuevo = raiz.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
    aplicarTema(nuevo);
    try { localStorage.setItem('tema', nuevo); } catch (e) { /* almacenamiento no disponible */ }
  });

  // Si la persona no eligió un tema manualmente, sigue el cambio del sistema
  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function (e) {
    var guardado = null;
    try { guardado = localStorage.getItem('tema'); } catch (err) {}
    if (!guardado) aplicarTema(e.matches ? 'dark' : 'light');
  });

  // Cierra el menú móvil al elegir una sección
  var menu = document.getElementById('menu');
  document.querySelectorAll('#menu .nav-link').forEach(function (enlace) {
    enlace.addEventListener('click', function () {
      if (menu.classList.contains('show')) {
        bootstrap.Collapse.getOrCreateInstance(menu).hide();
      }
    });
  });

  // Año del pie de página
  document.getElementById('anio').textContent = new Date().getFullYear();
})();
